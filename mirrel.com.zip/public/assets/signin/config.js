var clientId = "480785640282-pri4rt3btbv7gtv0f68r0aoj96v44559.apps.googleusercontent.com";
var api = "http://localhost/app/tradingapp/public/";
var home = "http://localhost:4200/#/";
