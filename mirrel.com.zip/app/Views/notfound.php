<?= view('app_global/nav'); ?>
<?= view('app_global/board_header'); ?>

 
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="my-5 text-center">
                <img src="<?= base_url()?>assets/img/no-data.jpg" style="max-width: 300px;width:auto ">
                <p>No Data Shared</p>
            </div>
        </div>
    </div>
</div>