<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>JSON dev</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'> 
</head>
<body>
<pre>
<?php print_r($user);?>
</pre>
<script src="http://localhost:35729/livereload.js?snipver=1"></script>
</body>
</html>